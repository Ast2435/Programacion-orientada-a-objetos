//Clase estudiante
public Class Estudiante{
	String nombre;
	int boleta;
	double calificacion;

	public void setNombre(String nombre){
		this.nombre = nombre;
	}

	public void setBoleta(int boleta){
		this.boleta = boleta;
	}

	public void setCalificacion(double calificacion){
		this.calificacion = calificacion;
	}
}